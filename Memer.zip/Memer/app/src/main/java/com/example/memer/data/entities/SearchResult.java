package com.example.memer.data.entities;

import java.util.List;

public class SearchResult {

    private SearchInformation searchInformation;
    private List<SearchItem> items;

    public SearchInformation getSearchInformation() {
        return searchInformation;
    }

    public void setSearchInformation(SearchInformation searchInformation) {
        this.searchInformation = searchInformation;
    }

    public List<SearchItem> getItems() {
        return items;
    }

    public void setItems(List<SearchItem> items) {
        this.items = items;
    }
}
