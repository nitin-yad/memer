package com.example.memer.utils;


import com.example.memer.data.entities.SearchResult;
import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class HttpUtil {

    public static SearchResult sendGet(String searchString){

        final String key = "AIzaSyCn9uzTVQEI2JsMieW5UvskxT5UGyQd7ZE";
        HttpURLConnection urlConnection = null;
        try {
            URL url = new URL("https://www.googleapis.com/customsearch/v1?key="+key+ "&cx=016066090498551417788:hqcsgnbke8f&q="+ searchString + "&alt=json&searchType=image");
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.setRequestProperty("Accept", "application/json");
            Gson gson = new Gson();
            InputStream inputStream = urlConnection.getInputStream();
            return gson.fromJson(new BufferedReader(new InputStreamReader(inputStream)), SearchResult.class);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if(urlConnection != null)
                urlConnection.disconnect();
        }
        return null;
    }
}
