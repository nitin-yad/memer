package com.example.memer.data;

import android.os.AsyncTask;

import com.example.memer.data.entities.SearchItem;
import com.example.memer.data.entities.SearchResult;
import com.example.memer.utils.HttpUtil;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;

public class DataSource extends AsyncTask<String, Void, List<String>> {

    private String[] keywords = {"idealist", "new", "trending", "2020", "2019", "best", "indian", "english", "hindi"};

    @Override
    protected List<String> doInBackground(String... strings) {

        List<String> links = getLinks();
        while(links.size()<10){
            links.addAll(getLinks());
        }
        return links;
    }

    private List<String> getLinks(){

        int index = getRandomInt()%keywords.length;
        SearchResult searchResult = HttpUtil.sendGet(keywords[index]+" meme");
        List<String> images = new LinkedList<>();
        if (searchResult != null) {
            for(SearchItem item: searchResult.getItems()){
                if(item.getLink().contains("jpeg") || item.getLink().contains("png") || item.getLink().contains("jpg"))
                    images.add(item.getLink());
            }
        }
        return images;
    }

    private int getRandomInt(){

        Random random = new Random();
        return random.nextInt() & Integer.MAX_VALUE;
    }
}
